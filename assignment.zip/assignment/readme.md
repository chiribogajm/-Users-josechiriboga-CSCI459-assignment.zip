#READ ME FILE

## Directories

### adr

This directory contains the Architectural Design Records

### mysql

This directory contains the files necessary to build the Docker container for the mysql database.

### wordpress

This directory contains the files necessary to build the Wordpress container for the Wordpress content management system.

cd ~/CSCI459/assignment/mysql
docker build -t mysql-459 .
docker build -t wordpress-459 .

docker run --rm --name wp-mysql -d mysql-459
docker run --rm --name wp --link wp-mysql:mysql -p 8080:80 -d wordpress-459

